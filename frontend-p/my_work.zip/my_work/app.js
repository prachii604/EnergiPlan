// To-do List Functionality
function addTodo() {
  const input = document.getElementById("todoInput");
  const task = input.value.trim();
  if (task === "") return;

  const li = document.createElement("li");
  li.textContent = task;

  const ul = document.getElementById("todoList");
  ul.appendChild(li);

  input.value = "";
}

// Best Time Output Hook (optional if forecast was retrieved)
if (document.getElementById("bestTimeOutput") && localStorage.getItem("lastForecast")) {
  document.getElementById("bestTimeOutput").innerHTML = localStorage.getItem("lastForecast");
}

// Store forecast output when on index.html
if (document.getElementById("forecastOutput")) {
  const origGetForecast = getForecast;
  getForecast = function () {
    origGetForecast();
    setTimeout(() => {
      const forecastEl = document.getElementById("forecastOutput");
      if (forecastEl && !forecastEl.classList.contains("hidden")) {
        localStorage.setItem("lastForecast", forecastEl.innerHTML);
      }
    }, 1500); // Give some time for fetch to complete
  };
}
// Move selected preset task to To-Do List
function moveToTodo(checkbox) {
  if (checkbox.checked) {
    const taskText = checkbox.parentElement.textContent.trim();
    const li = document.createElement("li");
    li.textContent = taskText;

    document.getElementById("todoList").appendChild(li);

    // Disable the checkbox after use
    checkbox.disabled = true;
    checkbox.parentElement.style.textDecoration = "line-through";
    checkbox.parentElement.style.color = "#999";
  }
}
// Pre-saved Task Checkbox Toggle Logic
function moveToTodo(checkbox) {
  const taskText = checkbox.parentElement.textContent.trim();
  const todoList = document.getElementById("todoList");

  const existingItem = [...todoList.children].find(li => li.textContent === taskText);

  if (checkbox.checked) {
    if (!existingItem) {
      const li = document.createElement("li");
      li.textContent = taskText;
      todoList.appendChild(li);
    }

    checkbox.parentElement.style.textDecoration = "line-through";
    checkbox.parentElement.style.color = "#999";
  } else {
    if (existingItem) todoList.removeChild(existingItem);

    checkbox.parentElement.style.textDecoration = "none";
    checkbox.parentElement.style.color = "#000";
  }
}


